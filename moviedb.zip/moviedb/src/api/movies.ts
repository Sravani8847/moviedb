import dotenv from 'dotenv';
dotenv.config();

// Types for the API response
interface Movie {
    title: string;
    release_date: string;
    vote_average: number;
    editors?: string[]; // Optional editors array
}
  
  // Updated API Configuration
  if (!process.env.TMDB_TOKEN) {
    throw new Error('TMDB API token is not defined in environment variables');
  }
  
  const API_KEY = process.env.TMDB_TOKEN as string;
  const BASE_URL = "https://api.themoviedb.org/3";
  
  // Add this interface above the getMovieEditors function
  interface MovieCredits {
    cast: any[];
    crew: {
      id: number;
      name: string;
      known_for_department: string;
      job: string;
    }[];
  }
  
  /**
   * Fetches credits for a specific movie
   * @param movieId - The ID of the movie
   * @returns Promise with array of editor names
   */
  async function getMovieEditors(movieId: number): Promise<string[]> {
    const options = {
      method: 'GET',
      headers: {
        accept: 'application/json',
        Authorization: `Bearer ${API_KEY}`
      }
    };
  
    try {
      const response = await fetch(
        `${BASE_URL}/movie/${movieId}/credits?language=en-US`,
        options
      );
  
      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }
  
      const data = await response.json() as MovieCredits;
      
      // Remove console.log and fix the editors extraction logic
      const editors = data.crew
        .filter(person => person.known_for_department === 'Editing')
        .map(editor => editor.name);
  
      return editors;
    } catch (error) {
      console.warn(`Failed to fetch editors for movie ${movieId}:`, error);
      return []; // Return empty array if credits fetch fails
    }
  }
  
  /**
   * Fetches movies from TMDB API for a specific year with pagination
   * @param year - Year in YYYY format
   * @returns Promise with MovieResponse
   */
  export async function getMoviesByYear(year: number): Promise<Movie[]> {
    const options = {
      method: 'GET',
      headers: {
        accept: 'application/json',
        Authorization: `Bearer ${API_KEY}`
      }
    };
  
    try {
      const response = await fetch(
        `${BASE_URL}/discover/movie?language=en-US&page=1&sort_by=popularity.desc&primary_release_year=${year}`,
        options
      );
  
      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }
  
      const rawData: any = await response.json();
      
      // Process movies sequentially and handle individual failures
      const movies: Movie[] = [];
      for (const movie of rawData.results) {
        try {
          const editors = await getMovieEditors(movie.id);
          movies.push({
            title: movie.title,
            release_date: movie.release_date,
            vote_average: movie.vote_average,
            editors
          });
        } catch (error) {
          // If getting editors fails, still add the movies without editors since it's optional
          movies.push({
            title: movie.title,
            release_date: movie.release_date,
            vote_average: movie.vote_average,
            editors: []
          });
        }
      }
      return movies;
  
    } catch (error) {
      throw new Error(`Failed to fetch movies: ${error}`);
    }
  }

// Updated example usage
async function fetchMovies(year: number) {
  try {
    const movies = await getMoviesByYear(year);
    console.log(movies); // Array of movies directly
    return movies;
  } catch (error) {
    console.error(error);
    throw error;
  }
} 

// Export the function to use it in other files
export { fetchMovies }; 