import express from 'express';
import { getMoviesByYear } from './api/movies';

const app = express();
const port = process.env.PORT || 3000;

app.get('/:year', async (req, res) => {
  try {
    const year = parseInt(req.params.year);    
    const movies = await getMoviesByYear(year);
    res.json(movies);
  } catch (error) {
    res.status(500).json({ error: 'Failed to fetch movies' });
  }
});

app.listen(port, () => {
  console.log(`Server running at http://localhost:${port}`);
}); 